# Tutorial RCM — un escenario, varios layouts

Abre **Ayuda → Tutorial del proyecto** para conservar esta guía dentro del editor. Los enlaces seleccionan el elemento que se explica. En el juego, inicia **RCM · Tutorial de creación** como partida nueva. Todas las escenas usan EastLondon, con su entorno original gris. No hay enemigos al llegar.

**Ver el inicio del jugador:** abre **Espacio 3D → Inicio**. El botón vuelve al layout inicial, selecciona **Entradas → Inicio del jugador · calle de EastLondon** y enfoca el marcador. En Propiedades puedes editar XYZ/orientación; el gizmo permite moverlo. Para otras llegadas, selecciona una entrada del árbol y pulsa Enfocar.

Revisión 0.9.4: el usuario confirmó que puede caminar desde `[-176,-768,384]`, pero los PNJ no aparecían. Se corrige la referencia de AI a su archivo `.nai` y se añade recuperación del spawn si CreateThing devuelve 0. Su resultado nativo sigue por comprobar. Empieza una partida nueva: la guía añade flags y entradas de journal al contrato de guardado.

**Guía dentro del juego:** al llegar se carga automáticamente **Tutorial RCM: empieza aquí** en el journal, antes de crear personajes. Abre su descripción para leer el orden de estaciones y cómo editar cada función. [Journal inicial](rcm://workshop/events/journal_init) carga la quest `guide`; en Campaña / Quests puedes cambiar su descripción y sus instrucciones. No depende de que puedas hablar con la mentora. **Aprender a crear** es otra quest: la inicia la mentora y avanza durante el circuito.

## Primer recorrido

1. Abre el journal y lee **Tutorial RCM: empieza aquí**. Habla con la mentora, delante del inicio, e inicia la lección.
2. La cineasta está a la izquierda: compara diálogo automático, diálogo con plano propio y cutscene de ocho segundos.
3. La custodia está a la derecha: pide la llave. Su inventario de NPC es independiente del tuyo.
4. La guardiana, al otro lado del punto de inicio, permite cambiar de layout cuando llevas la llave y tienes el flag de acceso.
5. En el segundo layout de la misma calle, la guía crea **una rata básica** sólo si lo eliges. Tras matarla, pide ir al final. Puedes volver al taller sin combatir.
6. En el tercer layout, completa la quest. Guarda/carga y vuelve al taller: comprueba flags, actores y premios. Retirar la rata sin matarla no completa la quest ni entrega el premio; esa prueba requiere una partida nueva si después quieres hacer el circuito de combate.

## Cómo editar cada función

| Función | Elemento y pasos en el editor | Prueba en juego |
|---|---|---|
| Punto de inicio y orientación | [Entrada safe](rcm://workshop/entries/safe). Mover en 3D o editar XYZ/yaw; Campaña → seleccionar escena → Llegada por defecto. | Jugador junto a los NPC; guardar/cargar conserva su posición. |
| Actor, plantilla, prop y posición | [Mentora](rcm://workshop/actors/mentor), [barril](rcm://workshop/objects/barrel). Clic derecho en 3D → Actor / Objeto; elegir catálogo y clic en suelo. Supr elimina. | NPC y prop propios sobre geometría original. |
| Conversación, nodos y respuestas | [Menú de mentora](rcm://workshop/conversations/menu). Historia → añadir nodo/línea/respuesta; Gráfico de historia → GOTO/RETURN. Herramientas vuelve al nodo de apertura. | Respuestas diferentes, retorno al menú y cierre que devuelve controles. |
| Cámara de conversación | [Automática](rcm://workshop/conversations/camera), [sobre hombro](rcm://workshop/conversations/framed). Propiedades → Cámara de diálogo. Automática no impone una cámara nuestra. | Comparar ambas; probar rechazo, cierre y aborto. |
| Cutscene con actor caminando | [Timeline](rcm://workshop/sequences/walk_scene). Campaña → + Cámara → Actor en movimiento; + Plano añade tiempo, actor, preset y transición. | Caminante y tres planos; a los ocho segundos se devuelve el control. |
| Travelling original | [EASTOttoVan](rcm://workshop/sequences/original_path). Seleccionar Travelling original NCP; duración limita la prueba. | **Experimental**: recorrido original de EastLondon, sin reescribirlo. Comprobar encuadre y Release. |
| Waypoints y recorridos | [Paseo](rcm://workshop/paths/walker_walk), [waypoint](rcm://workshop/waypoints/walker_b). Colocar puntos en 3D; + Recorrido, ordenar puntos y elegir bucle. Separador vertical da más espacio al formulario. | Mentora → Herramientas: iniciar/detener recorrido y AI. |
| Inventario inicial de NPC | [Custodia](rcm://workshop/actors/keeper) → Editar inventario inicial → + Del catálogo. Filtra Objetos/Armas/Armaduras; añade copias, quita y Aplica. | Una llave y un libro dentro del NPC, sin aparecer además en el suelo. No se prometen slots de equipo. |
| Llave como objeto, flag y salida lógica | [Evento unlock](rcm://workshop/events/unlock). Condición ALL: flag access y owns_item key; acción Viaje → escena y llegada. | Sin ambos requisitos no cambia layout. La llave se consume al completar. Esta salida lógica no anima una puerta física. |
| Scene/layout sobre mismo mapa | Campaña → + Escena → Nuevo layout sobre este level, Duplicar layout, u Otro level. Contenido independiente por escena; acción Viaje selecciona destino y entrada. | Taller, combate y final comparten geometría; NPC y encuentros cambian. |
| Trigger, entrar/salir y pickup | [Volumen station](rcm://workshop/triggers/station), [evento pickup](rcm://workshop/events/pickup). Mover/tamaño en 3D; eventos de entrada, salida y objeto recogido. | Cerca de la guardiana aparece un libro; recoge y consulta flags en Debug después de Leer trace. |
| Flags, condiciones ALL/ANY/NOT y timer | [key_seen](rcm://workshop/events/key_seen), [timer](rcm://workshop/events/timer). Historia → flags; evento → condiciones/acciones. | Flags en trace; timer de cuatro segundos. Algunas marcas sólo se observan en Debug, por eso el validador avisa que no cambian la historia. |
| Quests, pasos, experiencia | Campaña → quest Aprender a crear; eventos accept/cleared/finish. | Journal, tres pasos y premio una sola vez. |
| Encuentro y muerte | [Encuentro](rcm://combat/encounters/one_rat), [event cleared](rcm://combat/events/cleared). Añade enemigo con plantilla Rat, asigna al encuentro y crea desde evento. | Una rata opcional. Muerte y encuentro entregan flags; retirar sin matar no da premio. |
| Retirar prop, AI y movimiento | Menú mentora → Herramientas; eventos tool0..tool5. Seleccionar acción Pausar/Reanudar AI, Iniciar/Detener recorrido, Retirar entidad o Desactivar flag. | Caminante y barril cambian; el barril retirado no se recrea en esta partida. |
| Audio | [Arrival](rcm://workshop/events/arrival), [cutscene](rcm://workshop/events/cutscene). Iniciar música/ambiente; sonido con waypoint, volumen y radios. | Música Londres, ambiente callejero, trueno situado. Final detiene música/ambiente. |
| NOT, AI y Java propios | Templates / AI propios: T_tutor_mentor hereda businessWoman, AI_tutor cambia wanderRadius y RCMTutorActor es Java del proyecto. Clonar recurso conserva campos desconocidos. | Verificar atributos e inicialización en motor; no confundir compilación con aceptación nativa. |
| Build, paquetes y Debug | Guardar → Validar → BUILD CHRONICLE; Playtest / Debug → Deploy → Leer trace después de jugar. Los dos ejemplos se preparan conjuntamente para el acceso actual. | Paquetes propios en RCM; originales fuera de RCM intactos. |

## Funciones que todavía no son completas

No hay paridad total con Embrace. **Puertas físicas originales / open_exit / close_exit / control_door** requieren Cast ID, frames y script compatibles; el panel los ofrece como experimentales y esta guía explica cómo encontrarlos, pero no inserta IDs inventados en el tutorial. **Crear un travelling propio desde la cámara 3D** requiere un writer NCP validado y sigue pendiente. No se ofrecen edición de geometría, árbol AI completo, eliminación selectiva de todos los objetos estáticos originales ni multijugador verificado.

El travelling aquí reutiliza EASTOttoVan; no demuestra un writer NCP. El tutorial está generado y compilado con la API real, con suelo comprobado contra la malla; las nuevas cámaras, navegación, inventario múltiple, save/load y puertas requieren pruebas manuales en Redemption.

## Navegación 3D

Derecho + arrastrar mira; derecho + WASD/QE vuela; rueda con derecho cambia velocidad. Izquierdo arrastrado avanza y gira. Ambos botones arrastrados suben/bajan. Alt + izquierdo orbita; Alt + derecho acerca; Alt + central desplaza. Central también desplaza como acceso adicional. F enfoca. Clic derecho sin arrastrar abre acciones. Los gizmos conservan 1/2/3.
