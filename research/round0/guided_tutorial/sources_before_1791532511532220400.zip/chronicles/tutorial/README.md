# Tutorial paso a paso: un escenario, siete lecciones

Empieza una **partida nueva** en «RCM · Tutorial paso a paso». Esta revisión cambia el progreso respecto a los guardados anteriores.

El journal muestra el objetivo actual. Delante del punto de inicio aparece su profesor. Al completar u omitir una lección aparece el siguiente en el mismo sitio. El laboratorio está apartado, al fondo de la calle: no necesitas visitarlo para avanzar.

| Paso | Qué hacer en el juego | Dónde se edita |
|---|---|---|
| 1. Inicio | Habla con Tomás. Continuar u omitir. | [Entrada safe](rcm://workshop/entries/safe). Espacio 3D → Inicio; posición, orientación y llegada por defecto. |
| 2. Conversación | Vera explica texto, respuestas y cámara. Ver ejemplo sobre hombro u omitir. | [Conversación](rcm://workshop/conversations/camera), [ejemplo](rcm://workshop/conversations/framed). Propiedades → Cámara de diálogo. |
| 3. Cutscene | Otto presenta una escena de ocho segundos con paseo y tres planos. Verla u omitirla. | [walk_scene](rcm://workshop/sequences/walk_scene), [walker_walk](rcm://workshop/paths/walker_walk) y [waypoint final](rcm://workshop/waypoints/walker_b). |
| 4. Inventario | Elena entrega la llave. Omitir también la entrega para poder seguir. | [Elena](rcm://workshop/actors/keeper) → Editar inventario inicial → + Del catálogo; [next_4](rcm://workshop/events/next_4): Dar objeto y activar flag. |
| 5. Layout | Observa el barril y habla con el agente. Cambiar layout conserva la calle y retira barril y profesores anteriores. | [change_layout](rcm://workshop/events/change_layout). + Escena crea contenido sobre el mismo level. Viaje elige escena y entrada. |
| 6. Encuentro | El instructor crea una sola rata básica junto al inicio si lo pides. Matarla u omitir pasa al final. | [one_rat](rcm://combat/encounters/one_rat), [cleared](rcm://combat/events/cleared). Retirar la rata sin matarla no otorga el premio del combate. |
| 7. Guardado | Guarda, carga y comprueba llave y profesor. Terminar u omitir completa el tutorial. | [Final](rcm://finished/conversations/final). Guardar conserva el YAML; BUILD CHRONICLE lo compila; Deploy actualiza RCM. La partida se guarda dentro de Redemption. |

**El barril es decorado: no es una puerta ni se usa con un clic.** Las lecciones principales tienen dos opciones. Omitir prepara lo necesario para la siguiente. Sólo se carga un nuevo objetivo cada vez; los completados pueden aparecer en el historial del journal.

## Laboratorio opcional

[Laboratorio](rcm://workshop/actors/lab), separado de los profesores:

- Iniciar/detener [su propio recorrido](rcm://workshop/paths/lab_walk) y pausar/reanudar AI.
- Probar [EASTOttoVan](rcm://workshop/sequences/original_path), un travelling original **experimental**; no representa un writer NCP.
- Acercarte a la [zona del libro](rcm://workshop/triggers/station) para recoger un objeto. Debug → Leer trace muestra entrada, salida y pickup.
- Activar/desactivar una flag sin cambiar las siete lecciones.

## Verificación y límites

Compilación contra la API real y pruebas de las siete lecciones completas y omitidas. Las pruebas con dobles Java comprueban control y progresión; la cámara, animación, cambio de layout y save/load nuevos aún necesitan ensayo visual en Redemption.

No hay edición de geometría. Puertas físicas originales, writer NCP y multijugador siguen limitados. El paso 5 es una transición lógica, no una puerta animada.
