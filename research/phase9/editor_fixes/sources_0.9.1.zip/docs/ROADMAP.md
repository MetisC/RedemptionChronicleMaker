# Roadmap

Actualización Fase9/0.9.0: autoría directa de campañas, entradas visuales/llegadas, recorridos, controles limitados de puertas/exits, presets de cámara, sonido situado y diagnósticos. Un circuito único sustituye las demos desplegadas. Pruebas manuales de juego aplazadas por petición del usuario; no se inicia otra fase ni se declara aceptación. Pendientes prioritarios: B1/B2/B3, static/puertas completas y máquina independiente. Detalles en AUTHORING_MATURITY_REPORT.md.

Fases 1–3 conservadas con pruebas y evidencia histórica. Fase 4 implementa campañas sobre geometría original, quests nativas con pasos separados, inventario, encuentros, condiciones/acciones, Jump, cámara de actor, música y deploy. La demo completa se crea desde la GUI; los detalles verificados y pendientes están en PHASE4_REPORT.md.

El siguiente trabajo dentro del alcance entregado es el ensayo humano de la campaña en Redemption: journal, viajes/entradas, combate, item, reward y save/load. No se atribuye esta prueba al build.

Propuesta para una Fase 5 futura, sin iniciarla: cerrar contratos nativos antes de ampliar; objetivos en un único NQD si se confirma su gramática; NSD/exits/entradas y paths fiables; migración de saves; tests de combate/persistencia; optimización según mediciones.

No hay edición de geometría ni herramientas originales de autoría en el workflow. Todas las fuentes/builds/investigaciones permanecen en el workspace; la excepción de deploy se limita a RCM autorizado.
# Estado actual — Fase 7

Versión técnica 0.7.0 en estabilización autorizada por el usuario. [PHASE7_REPORT.md](PHASE7_REPORT.md) registra investigación de Embrace, corrección de asociaciones y perfiles de entorno. La aceptación beta depende de [RELEASE_BLOCKERS.md](RELEASE_BLOCKERS.md), que siguen abiertos. No se ha iniciado Fase 8. Las fases históricas descritas antes no sustituyen los resultados actuales ni convierten funciones pendientes en aceptadas.

