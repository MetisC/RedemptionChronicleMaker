# Redemption Chronicle Maker · 0.9.1

Actualización del editor: ratón horizontal corregido, cámara estable cerca de la vertical, contraste legible en tema oscuro/claro, pestañas fijas y eliminación con Supr o botón. «+ Actor» pide plantilla; borrar un actor retira sus acciones de aparición en la misma operación deshacible. [Correcciones y comprobaciones](docs/EDITOR_FIXES_0_9_1.md).

Editor moderno de crónicas para **Vampire: The Masquerade — Redemption**. Reutiliza escenarios originales como geometría inmutable y genera directamente nuestra capa de mundo, conversaciones, quests, estado y Java. No utiliza Embrace, NOT Editor ni otros programas originales de autoría.

**Estado: implementación técnica de Fase 9 y auditoría externa; prueba manual del juego aplazada por el usuario.** Nueva campaña directa, entradas visuales, destinos de llegada, recorridos, cámara narrativa, sonido situado y despliegue con limpieza de archivos propios. 198 pruebas offline satisfactorias; las nuevas funciones aún no tienen aceptación nativa. [Madurez](docs/AUTHORING_MATURITY_REPORT.md), [auditoría](docs/AUTHORING_GAP_AUDIT.md), [checklist de paridad](docs/AURORA_PARITY_CHECKLIST.md).

## Abrir

Distribución portable: `build/portable/RedemptionChronicleMaker/RedemptionChronicleMaker.exe`. Conserva **toda esa carpeta**: incluye las bibliotecas y la JVM; el EXE solo no es suficiente. No necesita instalar Python. Al arrancar crea su `workspace/`, detecta el juego o solicita su ubicación y genera catálogos leyendo la instalación. Los originales no se incluyen.

Para trabajar directamente con este workspace:

```powershell
python editor.py chronicles/circuit/project.yaml
```

Si Python no está en PATH, en este equipo está en `C:\Users\Usuario\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe`.

Si falla el controlador gráfico: `python editor.py --safe-mode`. Puedes editar, guardar y compilar sin crear OpenGL. `--reset-settings` conserva una copia de la configuración antes de restablecerla.

## Probar una crónica

Única demo desplegada: **Las voces de Londres · Circuito**, fuente `chronicles/circuit/project.yaml`. Contiene tres áreas, dos geometrías originales, seis NPC, cuatro enemigos opcionales, dos quests, dos recorridos, item, decisión, cámara, audio y regreso. Las demos antiguas se retiraron de RCM con backup completo en `research/phase9/retired_all_demos.zip`; sus fuentes siguen como regresiones. No se borraron partidas ni se cambió el acceso directo.

Cuando quieras probarla manualmente: abre tu acceso habitual → **Multiplayer → New Game → Las voces de Londres · Circuito**, partida nueva. Empieza con Victoria, habla con la guía y sigue el circuito del libro. El combate sólo se activa al elegirlo expresamente. [Guía y qué debe verse](docs/PHASE9_PLAYTEST.md). El circuito está compilado, no aceptado todavía dentro del juego.

En **Level base → Propiedades → Entorno original** puedes elegir un perfil NSD original asociado a la geometría. Se conserva el bloque entero de entorno y se crean nuestras entidades por separado. No hay todavía controles individuales de fog/ZClip/EAX ni borrado general de objetos de la escena estática base. Cambiar de level elimina el perfil anterior; los proyectos sin perfil mantienen la salida histórica.

Para actualizar: abre el circuito y usa **Guardar → Validar → Build → Deploy**. En este equipo Deploy del editor usa la carpeta indicada por tu acceso directo existente: `RCM/east_demo`. **Ejecutar** abre exactamente ese `.lnk`, conservando destino, argumentos y carpeta de inicio. Puedes elegirlo mediante **Acceso del juego…**. El acceso no se reescribe.

El checklist actual está en [RUNTIME_TEST_MATRIX.md](docs/RUNTIME_TEST_MATRIX.md). El log propio del circuito se escribe en `RCM/rcm_circuit/runtime_trace.log`; esa carpeta de logs no es otra crónica seleccionable. Las crónicas oficiales del juego permanecen.

Las campañas históricas se conservan. **RCM: Victoria y el pacto de Londres** tuvo aceptación del usuario en Fase 2. **Las voces de Londres** tuvo una regresión comunicada por el usuario; sus correcciones actuales necesitan repetición nativa.

## Un solo paquete

**Paquetes → Crear paquete de crónica** produce un `.rcmpack`. Es un ZIP verificado con manifest, NOB y clases. Al instalar se mantiene todo dentro de **RCM/<id>**, con copias de seguridad y sin sobrescribir archivos ajenos o modificados. El motor exige NOB en raíz y clases en `codex/`, pero todo pertenece a esa única carpeta.

**Exportar proyecto** produce `.rcmproject`: YAML y fuentes propias, sin recursos originales. Importar no ejecuta Java. Todo paquete que contenga clases exige revisión explícita antes de instalar; hashes no acreditan confianza ni autoría.

## Comandos de desarrollo

```powershell
python tools/rcm.py validate chronicles/circuit/project.yaml
python tools/rcm.py build chronicles/circuit/project.yaml
python tools/rcm.py package rcm_circuit build/rcm_circuit/rcm_circuit.rcmpack
python tools/rcm.py inspect-package build/rcm_circuit/rcm_circuit.rcmpack
python tools/quality.py --fast
python tools/quality.py
python tools/rcm.py verify-originals
```

La suite rápida usa fixtures sintéticos y no necesita juego, Qt ni Java. La completa necesita catálogos/copias técnicas extraídas y compilador/JVM; tampoco controla Redemption. Instalación de dependencias: `requirements.txt`, `requirements-editor.txt`, `requirements-dev.txt`, en `cache/vendor` y `cache/devtools`. [TESTING.md](docs/TESTING.md) detalla los comandos y categorías.

## Límites actuales

Writer NOT experimental sobre tags contrastados; campos desconocidos conservados. Las entradas son transforms lógicos tras Jump, sin editar entrances del NIL. Los recorridos usan navegación original; puertas/exits sólo tienen controles restringidos y no sustituyen sus scripts. Sin selección fiable de contenido estático, cámara desde vista, loop de audio espacial persistente, geometría editable, disciplinas nuevas ni timeline completa. Save/load nativo, abortos, combate y red necesitan ensayos actuales. Cambiar la estructura persistente puede exigir partida nueva; no hay migrador de saves de Redemption.

Fuente técnica: instalación original, clases, bytecode y documentación real. Solo `RCM/` está autorizado para despliegue; el resto del juego permanece de solo lectura.

[Informe de Fase 6](docs/PHASE6_REPORT.md) · [Matriz de funciones](docs/FEATURE_MATRIX.md) · [Bloqueos](docs/RELEASE_BLOCKERS.md) · [Guía del editor](docs/EDITOR_GUIDE.md) · [Problemas conocidos](docs/KNOWN_ISSUES.md) · [Formatos](docs/FORMAT_NOTES.md) · [Evidencia](docs/ENGINE_NOTES.md)
